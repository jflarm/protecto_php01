<style>
	ul{
		list-style: none;
		margin: 0;
		padding: 0;
	}

	ul li{
		float: left;
		padding: 15px;
	}
</style>
<ul>
	<li><a href="?page=contact">CONTACTO</a></li>
	<li><a href="?page=about">ABOUT</a></li>
</ul>


