<?php  
	
	const PATH_PROYECT = 'http://localhost:8888/MATERIAL_DE_DESARROLLO/CURSOS/COSAS_CON_FRANCIS';
	
	const SERVER_NAME = 'localhost';
	const USER_NAME = 'root';
	const PASSWORD_DB = 'root';
	const DATA_BASE = 'blog';

	

?>