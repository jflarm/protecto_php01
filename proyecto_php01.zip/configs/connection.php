<?php  
	require_once 'config.php';

	$connection = mysqli_connect(SERVER_NAME, USER_NAME, PASSWORD_DB, DATA_BASE);
	
?>